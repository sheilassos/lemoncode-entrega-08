import * as PrintList from "./client-list-business";

window.onload = function() {
    PrintList.printClientsAccounts();
};